import logging

def dummy():
 return True
